-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 07, 2013 at 01:32 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `smart_mall`
--

-- --------------------------------------------------------

--
-- Table structure for table `cinema_data`
--

CREATE TABLE IF NOT EXISTS `cinema_data` (
  `Movie_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Movie_Name` varchar(255) DEFAULT NULL,
  `Movie_TicketPrice` int(11) DEFAULT NULL,
  `Movie_ShowDate` date DEFAULT NULL,
  `Movie_ShowTime` time DEFAULT NULL,
  `Movie_Format` varchar(255) DEFAULT NULL,
  `Movie_CinemaHall` varchar(255) DEFAULT NULL,
  `Movie_Description` longtext,
  `Movie_TrailerURL` varchar(255) DEFAULT NULL,
  `User_ID` smallint(20) NOT NULL DEFAULT '0' COMMENT 'User who added this Cinema data',
  PRIMARY KEY (`Movie_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `cinema_data`
--

INSERT INTO `cinema_data` (`Movie_ID`, `Movie_Name`, `Movie_TicketPrice`, `Movie_ShowDate`, `Movie_ShowTime`, `Movie_Format`, `Movie_CinemaHall`, `Movie_Description`, `Movie_TrailerURL`, `User_ID`) VALUES
(1, 'Iron Man 3', 350, '2013-06-03', '12:15:00', 'DVD', '001', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney', '', 32),
(2, 'Iron Man 3', 350, '2013-06-03', '15:15:00', 'DVD', '002', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney\r\n', '', 32),
(3, 'Iron Man 3', 350, '2013-06-03', '18:15:00', 'DVD', '001', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney\r\n', '', 32),
(4, 'Iron Man 3', 350, '2013-06-03', '21:15:00', 'DVD', '002', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney', '', 32),
(5, 'Iron Man 3', 350, '2013-06-03', '12:15:00', 'DVD', '001', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney', '', 32),
(6, 'Iron Man 3', 350, '2013-06-04', '12:15:00', 'DVD', '001', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney', '', 32),
(7, 'Iron Man 3', 350, '2013-06-04', '12:15:00', 'DVD', '002', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney', '', 32),
(8, 'Iron Man 3', 350, '2013-06-04', '12:15:00', 'DVD', '001', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney', '', 32),
(9, 'Iron Man 3', 350, '2013-06-05', '12:15:00', 'DVD', '001', 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. This journey, at every turn, will test his mettle. With his back against the wall, Stark is left to survive by his own devices, relying on his ingenuity and instincts to protect those closest to him. As he fights his way back, Stark discovers the answer to the question that has secretly haunted him: does the man make the suit or does the suit make the man? (c) Disney', '', 32),
(10, 'A young Pakistani man is chasing corporate success', 350, '2013-06-03', '12:15:00', 'DVD', '002', 'A young Pakistani man is chasing corporate success on Wall Street. He finds himself embroiled in a conflict between his American Dream, a hostage crisis, and the enduring call of his family''s homeland.\r\n', '', 32),
(11, 'A young Pakistani man is chasing corporate success', 350, '2013-06-04', '18:15:00', 'DVD', '002', 'A young Pakistani man is chasing corporate success on Wall Street. He finds himself embroiled in a conflict between his American Dream, a hostage crisis, and the enduring call of his family''s homeland.\r\n\r\n', '', 32),
(12, 'A young Pakistani man is chasing corporate success', 350, '2013-06-05', '12:30:00', 'DVD', '001', 'A young Pakistani man is chasing corporate success on Wall Street. He finds himself embroiled in a conflict between his American Dream, a hostage crisis, and the enduring call of his family''s homeland.\r\n\r\n', '', 32),
(13, 'A young Pakistani man is chasing corporate success', 350, '2013-06-06', '15:15:00', 'DVD', '001', 'A young Pakistani man is chasing corporate success on Wall Street. He finds himself embroiled in a conflict between his American Dream, a hostage crisis, and the enduring call of his family''s homeland.\r\n\r\n', '', 32),
(14, 'Don 2', 600, '2013-05-15', '04:10:00', 'HD', 'Hall 4', 'An international gangster turns himself in, then dramatically escapes - only to face treachery and betrayal.', 'http://www.imdb.com/video/imdb/vi2265947673', 26);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('61f07892a32d15f253258e76ab51cfe8', '127.0.0.1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.59 Safari/535.7', 1327240726, 'a:2:{s:8:"username";s:15:"jambola@jam.com";s:9:"logged_in";b:0;}'),
('8cde19154dda77c0a54c61caa557a0cc', '127.0.0.1', '0', 1327224790, ''),
('19fe9c4d06999ac80e909ad31158d91b', '127.0.0.1', '0', 1327226393, ''),
('a6da1e82194eb888219e42c2d06f1fef', '127.0.0.1', '0', 1327226406, ''),
('9f4d28ec6adf089f14f4918783817f84', '127.0.0.1', '0', 1327226436, ''),
('cf7dbde871b35e1d834a3a2cbeef0e5b', '127.0.0.1', '0', 1327224662, ''),
('39a1e0bda18c0d83097afa32909b2da9', '127.0.0.1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.59 Safari/535.7', 1327226376, 'a:2:{s:8:"username";s:19:"to.msaads@gmail.com";s:9:"logged_in";b:0;}'),
('da305b19933e38c01f3600116287979d', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1284.0 Safari/537.13', 1367562433, ''),
('86da4f0268de7d1b79634b2d8b312801', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1284.0 Safari/537.13', 1367562466, 'a:2:{s:8:"username";s:19:"to.msaads@ymail.com";s:9:"logged_in";b:0;}'),
('0adb42324388aea6a607679a9bbd3d2d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.94 Safari/537.36', 1370151011, 'a:2:{s:8:"username";s:20:"shujaan2@hotmail.com";s:9:"logged_in";b:0;}'),
('3627ebd11300057d379ea104b3f0e7db', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1284.0 Safari/537.13', 1370166465, 'a:2:{s:8:"username";s:20:"shujaan2@hotmail.com";s:9:"logged_in";b:0;}'),
('5275fef1c9cfa039adb9db80abe36e9d', '0.0.0.0', '0', 1370174135, ''),
('4b033d0f7954b4bffb0c5a9b4e544eee', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370184791, 'a:2:{s:8:"username";s:20:"shujaan2@hotmail.com";s:9:"logged_in";b:1;}'),
('93c486d002a429fdbb9ece0fa31622f3', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370198339, ''),
('b3f40e81b890e252d1ed79d969769f8a', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370200023, ''),
('2a4e163da5d1c19eb3391530a8e7c643', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370200740, ''),
('d8112173d5d56f8e24ff613a734f61ca', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370200841, ''),
('5306b76c4c832e8c3085cf0152b6162f', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370203046, ''),
('a32a15dc7fe67f6c723365a3e521e808', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370212043, ''),
('4b6432096d242b0bfa0ee8e6295c66c7', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370212051, ''),
('a6a0ea75cc9d3d69a7fa4accf25985f2', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370332778, ''),
('03407b2cf5e65cfe18c289d792f8ea5a', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370338624, ''),
('b2fd4a24fa184b3d62859d96b9e59dd1', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370338832, ''),
('ffa9636b1677e954a695ea902b058f39', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370339049, ''),
('0c25848189f4e902902d1dce75ee3d29', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370339203, ''),
('c39f1dad57cbc91170ea4c8869377927', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370339906, ''),
('215199c9c977d800f9479b5137984def', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370339992, ''),
('82eaeda4c2b19ef8386a3d812c83c983', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370340056, ''),
('39a6f9f1ee6ca1d75931e030e3ef17cb', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370344492, ''),
('8e01c927c01ea75cc73a4b3744debc47', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370344681, ''),
('bbbac8a2a50f3cb9f70534093a820485', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370344945, ''),
('123294b8726d6a732b9980841755633d', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370347298, ''),
('9bb9ba6ab466af5a5ec59a9d07fd2bc0', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370347482, ''),
('5532fcac9dac2fab3e9a7023dcb7561f', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370347532, ''),
('009140597fb4ca46c27a99f43ffd2fd8', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370347710, ''),
('89be49d790a66d2d86e98bb2d6e121b2', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370347897, ''),
('bbb350d86b91a1e6ea42962e4d719894', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370347947, ''),
('8216320f6085afd5b03b870e8a628247', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370348024, ''),
('61359c552e3f083d0096b85cf99ce2b8', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370348274, ''),
('a972e4996bf2f9450daa1f1e2f5ae3df', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370349274, ''),
('3603c51a253550b3aa6ef3bf9ce73058', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370349721, ''),
('48466304403e2c20d59a6d21f5a5b44f', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370349764, ''),
('3e24c3fbbc6f6bea8a94af9a661185fd', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370349796, ''),
('df0577b44aa4d5faaa2b781aab3b9eb0', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370349796, ''),
('f233b66be3179a3e34fe765aaace4437', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370349847, ''),
('c132723ce2d1a97b3e732959dcc0eb80', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370349932, ''),
('f23bf60054819514b064baf90d1b9df3', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370350002, ''),
('956b6c3fb42ac409a336c01ab1ca3255', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370350142, ''),
('dc4f6e4dd525e1af3452bc6cbd06a60b', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370350400, ''),
('c6accc8fde244a8b7268d02d7bdf2ad5', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370350879, ''),
('a95242ddccc53fab08a2604a7b4cf21f', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370351437, ''),
('e43c273b5590681fa5189f9fe207e628', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370351760, ''),
('6b7bb7fe3b0bb7b49c5ef8826add5737', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370352781, ''),
('c58d0d88024b7b43c135e96b651c6cb4', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370367568, ''),
('6450330ee491ced4731fc2af74d49129', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370367704, ''),
('47e4139d2b52c5d2c656fdaa09e10e7d', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370369382, ''),
('c8e5b1325537b17a8801eda2166881c4', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370369685, ''),
('be38ecb819f1be36775b1cbadcc851a0', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370369794, ''),
('16e1d819b0b3e28ef968c9437864492a', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370370019, ''),
('da6579b6d691e6d983b27c6c6d4b13e0', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370370464, ''),
('c9de725f164d055067a60c339c38952e', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370370516, ''),
('1488fcb1cca8b62009b99efe2c381b2a', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370371011, ''),
('43535f1b972d8d06b45cfa1e4a422cad', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370371593, ''),
('0ac9b46f8d03b095bf9fa198345cec3b', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370371673, ''),
('5776efa5a905c454de84d129b561a29b', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370373240, ''),
('5afe2d40713fd66a8151d9009ca9a7f1', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370373334, ''),
('34d9e5c52e5538daceae7d7e1ec75256', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370373571, ''),
('9c45cfe07a3d8ec613d76ba9ad150020', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370373891, ''),
('2efaee2a489fad796c8db2dc6ac52f9a', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370374071, ''),
('6cc38c7a6e23c0a3f9f2d9433ef61360', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370375476, ''),
('2702d606dea6ad976183ade143dabc23', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370375502, ''),
('b86a3052ef6a4d152062c2f0bd6e1a77', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370376057, ''),
('cd3c6e09fb9a68596cc32e5566003b01', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370380635, ''),
('b43901998c899a9b50f3bf864e77e719', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370382264, ''),
('2c92e80429cf0d52987b06dd0627bf14', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370384516, ''),
('3936b260c795f519b7ea0ecaeeed40ff', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370384572, ''),
('7c4e16fece06cd0c42a732e1b4d4816f', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370384691, ''),
('202dd281086a4dd91606e4356db51e8a', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370385024, ''),
('895fa69c0cf0c3fd24706630d580e684', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370385133, ''),
('78efa12f2107469946ffa2d5dccbcf36', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370385442, ''),
('8f9b77f44b109cf379b216d1beca5588', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370386125, ''),
('06f90eab758f43bcbf5ff4b33ff44577', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370386403, ''),
('1dad103c162ba5248feddaed648552ae', '0.0.0.0', 'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20100101 Firefox/21.0', 1370386432, ''),
('1682948472db0361fa65033fbfcf4f64', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406235, ''),
('3e0ab0de740130fac564706725031a9a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406238, ''),
('419c114d0837fe8936fe5d2e9f1266a1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406240, ''),
('571a30fc81fbe438cf126f0db2f602a7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406242, ''),
('0b58088c4ca7abef0ab9d77f5a8d99e2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.94 Safari/537.36', 1370406405, 'a:2:{s:8:"username";s:25:"mother_care@smartmall.com";s:9:"logged_in";b:0;}'),
('18a0e82c604e35a3a8810d7734915904', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406417, ''),
('07b02d833b2803f476dce65ea5127155', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406419, ''),
('662caac8bdc3c3891c3553dbca0ded0f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406420, ''),
('5b3c81b955650d3ea829e7cfb6c0a649', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406422, ''),
('a9a6638725112e551287486cbfc4af8d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406423, ''),
('01a181666a3c8cc537957201c51fdf75', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406424, ''),
('020ff01020716975ab41e897a0a4b1bf', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0', 1370406424, ''),
('c26655d977bab6c4020b8462c62ea48a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406521, ''),
('e6a539d35df01b91e872c89907c9b982', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406523, ''),
('7291537f2791166129b2ed491db5fa3c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406524, ''),
('4bc9c8fe1e41523d5a1dc4960459622d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406526, ''),
('ebce36d49c19c1966a6666ad0759f5c0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406527, ''),
('ce0b63ddc02873a77fbcdfc73bb8e1e5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406528, ''),
('4fbf07866611c53ffe2d5fc15f31e96d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406528, ''),
('72dc42a83ffb97df4261b2ca98193be2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406530, ''),
('1a13075cbe0479be300215ef46bc6850', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406536, ''),
('1a7c28401d72f6f0334d1873bf15f763', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406536, ''),
('6e066ffd869eaa185de1be4cdd212a12', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406536, ''),
('80c9512beaa57452239e5c67dd835a35', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406538, ''),
('c774835cec8278c1447aa8e3598dc18e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406540, ''),
('68f15359c0359ddd18ec91bd322c0664', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406540, ''),
('26d2f7f4dd88dbfa8d809de6e57116e1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406540, ''),
('0f44a55fa81c0d86fa913fa76edfc7d8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406540, ''),
('8993867c802d37923461a4878b4a4165', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406541, ''),
('ad8ebe2915e2c2fc8b32bd9318c88a73', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406541, ''),
('9951689f3357b832828c369a16099b30', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406541, ''),
('d1d462774942ca6921c1842afa652dcd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406541, ''),
('7bb4c64eb2939fa6163fcc50ef246d12', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406632, ''),
('fa0eeb5f64955dd0420a166ae6122536', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406632, ''),
('0ed158fe786196c8a6e43726a29a03fa', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406632, ''),
('0f263d2ea1289d621512a69d7c8ac1ad', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406632, ''),
('8df8e97a3e35f2a69a24c70ce4b4fd58', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406646, ''),
('3d3b953812ff389b7392d0d0a31413ee', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406646, ''),
('633a27f93f133319913df9fa6eb6cf3f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406647, ''),
('7ffdd147a456fbc97fa40cd2273b6627', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406647, ''),
('bc103778db899c2cbd11030b0f6cad0b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406698, ''),
('3e299971b50eba08f8955ff41971cc8d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406698, ''),
('7a7cf0a4165c917869f7a4fe6156ec9b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406698, ''),
('1530004b711a2f2b050a30367d0682e7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406698, ''),
('90f418043da37a777dcdd714b1630d00', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406701, ''),
('4283b43f51762d175c0cb2f363c5dd6b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406701, ''),
('5195fe05cf38e55a227c0116d60482a4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406701, ''),
('0c922454c4cabb8ec8107a40f7aa6656', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406702, ''),
('8f8d296b2beee14bd90881d3ea07e859', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406740, ''),
('11195d186550507ea41f98f1f330c42e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406785, ''),
('189cf8f719b6438d8d687ef549eaa1ef', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406787, ''),
('bab93c46b5a343cd206f9d63c307737e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406790, ''),
('e9a5755a1646c7520543d14a7ad9d3df', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406791, ''),
('a964c3762a91f6b3fcf8451c876b98b1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406796, ''),
('600647097b10d5a26b08e393006f08a2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406796, ''),
('9244334a9bedc4cb4e97693d3e6e5b05', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370406797, ''),
('35282fbe327cf815fb68470adc74db5c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413171, ''),
('6019157e86446bd0004016be18d8399c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413183, ''),
('0de014cfcf9106f54762eef32813a4a4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413188, ''),
('0e266c1656d4d2d520375a442ae12a0b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413191, ''),
('1fc8fd3f6e6076a86e7094d564723068', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413191, ''),
('ab4d4d1e25bd16fa5f743c82082c5da1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413192, ''),
('e6ccae9dc2069389c9c4117453257ee4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413193, ''),
('f30608471086b1ed872d9142edaf1ba0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413194, ''),
('fd2846f0a216c6fe9f483c08cc197d28', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413194, ''),
('c436d52a0bd2eaa7de18c8c7f9721195', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413207, ''),
('0b27e90acec14bb7e6115e759efa5268', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413208, ''),
('4004856f6f2bc826d85505bcd705e28f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413208, ''),
('8a217cb91870afd848c4adc1f7391a3b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413212, ''),
('77559f2b964d9662185f7ec9a3985c18', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413212, ''),
('6229cb0ff743a359e637e6e8ec596609', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413212, ''),
('fbc4fd20eceee869a4f83934cee70bc3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413226, ''),
('e7325eb4a787fe45d2eeacac8523c746', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413226, ''),
('47602cc241e517526df8b43ef9691cf4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413226, ''),
('2ff7fe7bcbf3e680bb10970eab75f6c9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413230, ''),
('afdc9b2829686ccbeaf4027d9b067b80', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413233, ''),
('3e401ade35262c444311c77b4290f8c4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413233, ''),
('81ec9aae943d069d0861fcdb00247b30', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413233, ''),
('bd39858bf77371c3b334978ccbf3325c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370413233, ''),
('f5a175719230d9508c9cb2aad9934f55', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.94 Safari/537.36', 1370416509, 'a:2:{s:8:"username";s:20:"shujaan2@hotmail.com";s:9:"logged_in";b:0;}'),
('94e58a029f6ced1d64c5b15e8ce0cc09', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 1370430026, ''),
('d83b16d01c1a5bc45852371af24523b0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 1370608826, 'a:2:{s:8:"username";s:20:"cinema@smartmall.com";s:9:"logged_in";b:0;}');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `Notification_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Notification_Name` varchar(255) DEFAULT NULL,
  `Notification_Details` varchar(255) DEFAULT NULL,
  `Notification_StartDate` date DEFAULT NULL,
  `Notification_EndDate` date DEFAULT NULL,
  `User_ID` bigint(20) NOT NULL DEFAULT '0' COMMENT 'User who added this notification',
  PRIMARY KEY (`Notification_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`Notification_ID`, `Notification_Name`, `Notification_Details`, `Notification_StartDate`, `Notification_EndDate`, `User_ID`) VALUES
(2, 'Gmail user notification', '', '2013-05-13', '2013-05-31', 24),
(3, 'Gmail user notification', '', '2013-05-30', '2013-05-31', 24),
(4, 'Live user notification', '', '2013-05-16', '2013-05-25', 25),
(5, 'Welcome\r\n\r\n\r\n\r\n', '', '2013-06-01', '2013-06-30', 28),
(6, 'New Summer Lawn Launching\r\nComing soon', '', '2013-06-01', '2013-06-20', 28),
(7, '10% Discount on every items for limited time period', './uploads/notifications/discount.jpg', '2013-06-02', '2013-06-23', 28),
(8, 'Family Feasts\r\nInclude 10 Pcs Chicken\r\n5 Dinner Roll\r\n5 Reg. Fries\r\n5 Reg. Drink', './uploads/notifications/family-feasts-big.jpg', '2013-05-01', '2013-08-01', 29),
(9, 'New Big Filler', './uploads/notifications/new-big-filler.jpg', '2013-03-01', '2013-10-01', 29),
(10, 'Marvel''s "Iron Man 3" pits brash-but-brilliant industrialist Tony Stark/Iron Man against an enemy whose reach knows no bounds. When Stark finds his personal world destroyed at his enemy''s hands, he embarks on a harrowing quest to find those responsible. T', './uploads/notifications/iron_man_3_movie-wide.jpg', '2013-06-02', '2013-06-30', 32),
(11, 'Set in Fiction, this is a story of a country called Mulke Khudadad and set in one of its city, Falakabad. Within the city of Falakabad, the story mostly revolves around an area of the city called Yaadgaar Colony, which is an old historic district of pre-p', './uploads/notifications/17080-chambaili-1367061055-368-640x480_(1).JPG', '2013-06-02', '2013-06-30', 32),
(12, 'Fast & Furious 6 (2013)\r\nHobbs has Dom and Brian reassemble their crew in order to take down a mastermind who commands an organization of mercenary drivers across 12 countries. Payment? Full pardons for them all.\r\n\r\n', '', '2013-06-02', '2013-06-30', 32),
(13, 'Yeh-Jawaani-Hai-Deewani-\r\nDirector Ayan Mukerji’s second outing at the Box Office, after ‘Wake Up Sid’, is light, frothy at the primary level – and delves somewhat into the deeper recesses of human emotions at the secondary level. However, one thing emerg', './uploads/notifications/Yeh-Jawaani-Hai-Deewani-poster1.jpg', '2013-06-02', '2013-06-30', 32),
(14, 'The_Great_Gatsby_13\r\n', './uploads/notifications/The_Great_Gatsby_13.jpg', '2013-06-02', '2013-06-23', 32),
(15, 'The Smurfs\r\nWhen the evil wizard Gargamel chases the tiny blue Smurfs out of their village, they tumble from their magical world into New York City.\r\n\r\n', '', '2013-06-02', '2013-06-30', 32),
(16, 'The Reluctant Fundamentalist\r\nA young Pakistani man is chasing corporate success on Wall Street. He finds himself embroiled in a conflict between his American Dream, a hostage crisis, and the enduring call of his family''s homeland.\r\n\r\n', '', '2013-06-02', '2013-06-30', 32),
(17, 'Open House Sale at Gul Ahmed\r\n\r\nGood news for fashion lovers as Gul Ahmed has announced a big time Open House sale across the country. Shoppers can get the discount of as much as 70 % on the following high class items by IDEAS.\r\no Home Textiles\r\no Apparel', './uploads/notifications/GulAhmed_Image_1_A.JPG', '2013-06-01', '2013-06-23', 35),
(18, 'Summer Fashion 2013\r\n4 pm to 11 pm @ Al Rehab Village Compound Hall, Prince Sultan Road Near Holiday Inn Hotel,\r\nAl Khobar, Kingdom of Saudi Arabia.\r\n', './uploads/notifications/GulAhmed_Logo_Image_1_B.JPG', '2013-06-01', '2013-06-23', 35),
(19, 'English Shoes Collection\r\nUrban Men shoes in sleek, soft full grain leather design. Soft Leather Lining. Non-slip composition polymer shoes. Available now in stores.\r\n', './uploads/notifications/English_Boot_House_2_A.JPG', '2013-06-01', '2013-06-30', 36),
(20, 'New style in Casual Shoes Arrived in EBH.\r\n\r\nA shoe has so much to offer than to walk. Free Accessories and DISCOUNTS on dew of the variety (Till the last stocks).\r\n', './uploads/notifications/English_Boot_House_2_B.JPG', '2013-06-10', '2013-06-20', 36),
(21, 'Levis Pakistan presents Summer Sale 2013 – Upto 60% off!\r\n\r\nPioneers! How many of you have visited the Levi''s(R) store and made the most out of this sale? If not, then rush now to your nearest Levi''s(R) store and make this Summer special by treating yours', './uploads/notifications/Levis_3A.JPG', '2013-06-04', '2013-06-24', 37),
(22, 'Levis Pakistan Latest Watched Collection 2013 available in Pakistan\r\n\r\nThis season Levi''s® brings you a new range of breathtaking watches. We bet you will want one, the minute you set your eyes on it. The range is designed for everyone-for those who belie', './uploads/notifications/Levis_3B.JPG', '2013-05-20', '2013-06-20', 37),
(23, 'Spring/Summer in Store Now\r\n\r\nLevis gives all its Pioneers a chance to stand out from rest of the crowd. Visit your nearest Levis store for the collection of Spring/Summer 2013.\r\n', './uploads/notifications/Levis_3C.JPG', '2013-05-26', '2013-06-10', 37),
(24, 'Samsung BLOCKBUSTER Offer!\r\n\r\nEnjoy Gifts Worth Upto Rs. 111,000\r\nSamsung 43? 3D PDP Tv for Rs. 69,900 only.\r\n50% Discount on 3D glasses or Blu-Ray Player\r\n• Free 3D  Blu-Ray Player & a pair of glasses with a Samsung 3D LED TV\r\n• Free DVD Home Theater Sys', './uploads/notifications/Samsung_4A.JPG', '2013-06-09', '2013-06-30', 38),
(25, 'Samsung GALAXY  !!! Life Companion\r\n\r\nThe wait is over! Samsung S4 is in Pakistan. Official distributors Morris n Phillips.\r\n', './uploads/notifications/Samsung_4B.JPG', '2013-06-01', '2013-06-30', 38),
(26, 'Earth Hour\r\n\r\n‘Mothercare’ and ‘Early Learning Centre’ are celebrating ‘Earth Hour’ in collaboration with WWF-Pakistan on Saturday 31st March, 2013 between 7:45pm - 8:30pm.\r\n', './uploads/notifications/mothercare_5A.JPG', '2013-05-01', '2013-06-01', 39),
(27, 'Expert Parenting Show\r\n\r\nWin this Sports Combo for FREE via a Lucky Draw.\r\n', './uploads/notifications/Mothercare_5B.JPG', '2013-06-01', '2013-08-01', 39),
(28, 'Free \r\nCoca Cola Glass with any Large Meal', './uploads/notifications/Mcdonald-1.jpg', '2013-05-01', '2013-08-01', 30),
(29, 'Happy Meal', './uploads/notifications/Mcdonald-2.jpg', '2013-04-01', '2013-08-14', 30),
(30, 'Champions Meal\r\n\r\nKFC brings you a Meal for the Champions. This Summer support your team and enjoy Champions Trophy with the Champions Meal.\r\n', './uploads/notifications/KFC_1A.JPG', '2013-06-01', '2013-06-30', 29),
(31, 'Value Burger for Rs. 150/- by KFC\r\n\r\nKFC Pakistan brings "Value Burger" deal for its customers. Delicious and tasty burger for only Rs. 150/- ONLY - For order or delivery call 111-532-532.\r\n', './uploads/notifications/KFC_1B.JPG', '2013-06-01', '2013-07-30', 29),
(32, 'Big Box Deal by KFC\r\n\r\nKFC reads the minds of its fans perfectly and brings for them everything they love in a single box.\r\nThe new Big Box from KFC is now available for just Rs. 2000/-\r\n \r\n• The big Box includes:\r\n• 4 Zinger Burgers,\r\n• 4 Pieces Chicken,', './uploads/notifications/KFC_1C.JPG', '2013-05-01', '2013-08-14', 29),
(33, 'Our New Deals \r\nTasty, scrumptious and delicious Deals are in Town. Call now and enjoy great taste at your door step.\r\n', './uploads/notifications/14th_Street_Pizza_2_A.JPG', '2013-06-01', '2013-06-30', 41),
(34, 'Ordering is Now Social\r\n\r\nOrder with confidence! You have just found your new favorite pizza delivery.\r\n\r\nOrder Now… Login to facebook.com/14thstreetpizza\r\n', './uploads/notifications/14th_Street_Pizza_2B.JPG', '2013-06-01', '2013-08-31', 41),
(35, 'Dinner Buffet\r\n\r\nKabab-Ji welcomes to taste the best Lebanese food in Town at its Dinner Buffet.\r\n', './uploads/notifications/Kabab-Ji_3A.JPG', '2013-06-01', '2013-06-30', 42),
(36, 'Kabab-Ji Restaurant Ramadan Iftar Deal\r\nKabab-Ji restaurant invites you for Ramadan Iftar Deal 2013 @ Rs.1499/-\r\nContact Us:\r\nContact Email: reservations.karachi@sheraton.com\r\nAddress:  Club Road, Karachi, Pakistan-75530\r\nContact:  Phone: (92) (21) 356333', './uploads/notifications/Kabab-Ji_3B.JPG', '2013-05-01', '2013-08-31', 42),
(37, 'Party Catering\r\n\r\nEnjoy One Potato Two Potato Live at your own party. On the spot delicious fries n burgers. Just let us know the date n time leave the rest on us.\r\n\r\nVisit our website for further details. www.optp.com\r\n', './uploads/notifications/OPTP_5A.JPG', '2013-06-01', '2013-06-30', 44),
(38, 'Value Meals\r\n\r\n6 delicious burgers with the combination of Original Plain/ Masala Fries and Drinks.\r\n', './uploads/notifications/OPTP_5A1.JPG', '2013-06-01', '2013-07-31', 44);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_menu`
--

CREATE TABLE IF NOT EXISTS `restaurant_menu` (
  `Item_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Item_Name` varchar(255) DEFAULT NULL,
  `Item_Price` int(11) DEFAULT NULL,
  `User_ID` bigint(20) NOT NULL DEFAULT '0' COMMENT 'User who added this item',
  PRIMARY KEY (`Item_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=295 ;

--
-- Dumping data for table `restaurant_menu`
--

INSERT INTO `restaurant_menu` (`Item_ID`, `Item_Name`, `Item_Price`, `User_ID`) VALUES
(111, 'Sample Menu Name', 200, 26),
(222, 'Sample Menu Name 2', 2000, 26),
(223, 'Sample Menu Name', 200, 25),
(224, 'Sample Menu Name', 200, 25),
(225, 'Chicken Mania', 425, 29),
(226, 'Zinger Meal', 555, 29),
(227, 'Chicken Burger', 210, 29),
(228, 'Zinger', 285, 29),
(229, 'Mighty Zinger', 380, 29),
(230, 'Zinger Xtreme', 320, 29),
(231, 'Panini', 500, 29),
(232, 'Pizza Twister', 375, 29),
(233, 'Fish Zinger', 325, 29),
(234, 'Spicy Sub', 135, 29),
(235, 'Rice n Spice', 240, 29),
(236, 'Beef Burger', 100, 30),
(237, 'Cheese Burger', 125, 30),
(238, 'Spicy Chicken Burger', 125, 30),
(239, 'Double Cheese Burger', 280, 30),
(240, 'Fish O Fish', 260, 30),
(241, '6 Pcs Chicken McNugget', 265, 30),
(242, 'Regular Fries', 100, 30),
(243, 'Medium Fries', 125, 30),
(244, 'Large Fries', 160, 30),
(245, 'Regular Chocolate Shake', 125, 30),
(246, 'Regular Vanilla Shake', 125, 30),
(247, 'Regular Strawberry Shake', 125, 30),
(248, 'Medium Chocolate Shake', 160, 30),
(249, 'Medium Vanilla Shake', 160, 30),
(250, 'Medium Strawberry Shake', 160, 30),
(251, 'Large Chocolate', 195, 30),
(252, 'Large Vanilla Shake', 195, 30),
(253, 'Large Strawberry Shake', 195, 30),
(254, 'Foodpanda Exclusive ALL- DAY Deal', 1099, 41),
(255, '2 Slices, 2 Pieces Of Sidelines and 2 Soft Drinks ', 649, 41),
(256, '1 Slice, 2 Pieces of Sidelines and Soft Drink ', 399, 41),
(257, 'Slice 2 pcs of Side line, 500 ml Drink', 349, 41),
(258, 'Half 5 pcs of Side lines, 1.5 Ltr Drink.', 1099, 41),
(259, 'Premium Turkey Slice  ', 349, 41),
(260, 'Premium Turkey Half', 1099, 41),
(261, 'Premium Turkey Full', 1899, 41),
(262, 'Potato Wedges 175 Gms.', 129, 41),
(263, 'Garlic Bread 5 Pieces', 129, 41),
(264, 'Cheesy Bread 5 Pieces', 129, 41),
(265, 'Potato Skins 5 Pieces', 129, 41),
(266, 'Chicken Wings BBQ ', 299, 41),
(267, 'Chicken Wings Spicy', 229, 41),
(268, 'Kabab Halabi', 200, 42),
(269, 'Kabab Chicken', 180, 42),
(270, 'Kabab Khachakhach', 350, 42),
(271, 'Kabab Intabli', 280, 42),
(272, 'Kabab Lite', 250, 42),
(273, 'Kabab Eggplant ', 320, 42),
(274, 'Kabab Orfali', 270, 42),
(275, 'Lamb Chops', 280, 42),
(276, 'Arayes', 280, 42),
(277, 'Grilled Veal Fliet', 220, 42),
(278, 'Kabab Chicken', 180, 42),
(279, 'Fruit Platter ', 220, 42),
(280, 'Watermelon', 150, 42),
(281, 'Ice Cream', 120, 42),
(282, 'Karabij', 0, 42),
(283, 'Plain Fries', 120, 44),
(284, 'Masala Fries', 120, 44),
(285, 'BBQ Fries', 120, 44),
(286, 'Cheese Fries', 140, 44),
(287, 'Garlic Mayo Fries', 140, 44),
(288, 'Nacho Cheese Fries', 150, 44),
(289, 'Crispy Wings', 250, 44),
(290, 'Masala Wings', 260, 44),
(291, 'Buffalo Wings', 280, 44),
(292, 'Premium Chicken Burger', 250, 44),
(293, 'Jalapeño Premium Chicken Burge', 320, 44),
(294, 'Double Stack Beef Burger', 280, 44);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE IF NOT EXISTS `shopping_cart` (
  `ShoppingCart_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ShoppingCart_DatenTime` datetime DEFAULT NULL,
  `Shopping_User_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ShoppingCart_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `shop_info`
--

CREATE TABLE IF NOT EXISTS `shop_info` (
  `Shop_No` int(11) NOT NULL,
  `Shop_Name` varchar(255) NOT NULL,
  `Shop_Logo` varchar(255) NOT NULL,
  `User_ID` bigint(20) NOT NULL DEFAULT '0' COMMENT 'User who added this shop'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='For shop and restaurant users';

--
-- Dumping data for table `shop_info`
--

INSERT INTO `shop_info` (`Shop_No`, `Shop_Name`, `Shop_Logo`, `User_ID`) VALUES
(10, 'GulAhmed', './uploads/shops/gulahmed1.jpg', 28),
(110, 'KFC', './uploads/shops/a1.jpg', 29),
(112, 'McDonald''s', './uploads/shops/g.jpg', 30),
(101, 'GulAhmed', './uploads/shops/gulahmed3.jpg', 35),
(102, 'English Boot House', './uploads/shops/ebh1.jpeg', 36),
(103, 'Levis', './uploads/shops/levis1.jpg', 37),
(104, 'Samsung', './uploads/shops/samsung-logo1.jpg', 38),
(105, 'MotherCare', './uploads/shops/mothercare_logo_with_oval1.jpg', 39),
(202, '14th Street Pizza', './uploads/shops/14thstreetpizza1.jpg', 41),
(203, 'KababJi', './uploads/shops/kababji-logo1.jpg', 42),
(204, 'One Potato Two Potato', './uploads/shops/logo2.gif', 44);

-- --------------------------------------------------------

--
-- Table structure for table `store_data`
--

CREATE TABLE IF NOT EXISTS `store_data` (
  `Product_Code` int(11) NOT NULL,
  `Product_Name` varchar(255) DEFAULT NULL,
  `Product_Brand` varchar(255) DEFAULT NULL,
  `Product_QuantityInStore` int(11) DEFAULT NULL,
  `Product_UnitPrice` int(11) DEFAULT NULL,
  `Product_Poster` varchar(255) DEFAULT NULL,
  `User_ID` bigint(20) NOT NULL DEFAULT '0' COMMENT 'The user who added this product',
  PRIMARY KEY (`Product_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_data`
--

INSERT INTO `store_data` (`Product_Code`, `Product_Name`, `Product_Brand`, `Product_QuantityInStore`, `Product_UnitPrice`, `Product_Poster`, `User_ID`) VALUES
(1, 'Bisconni Biscuits 24 Ticky Packs', 'Bisconni', 24, 99, '', 31),
(2, 'Nestle Milo', 'Nestle', 24, 665, '', 31),
(3, 'Nestle UHT Milk', 'Nestle', 24, 639, '', 31),
(4, 'Oolala Flavour Milk', 'Oolala', 24, 199, '', 31),
(5, 'Fine Food Coconut Cookies', 'Fine', 24, 189, '', 31),
(6, 'Fine Food Fruit Cake', 'Fine', 24, 126, '', 31),
(7, 'Fine Food Sugar Coated Cookies', 'Fine', 24, 109, '', 31),
(8, 'Dairy Pure UHT Liquid', 'Dairy', 24, 719, '', 31),
(9, 'Icepac Chicken Shami', 'Icepac', 24, 349, '', 31),
(10, 'Menu Chicken Seekh', 'Icepac', 24, 389, '', 31),
(11, 'Dawn Chicken Nuggets', 'Dawn', 24, 439, '', 31),
(12, 'Chicken Quorma Cut Chicken Qourma Cut', 'Chicken', 1, 189, '', 31),
(13, 'Chicken Karahi Cut', 'Chicken', 1, 189, '', 31),
(14, 'Beef Mince', 'Beef', 1, 375, '', 31),
(15, 'All Pure Nectar', 'Pure', 24, 92, '', 31),
(16, 'Del Monte Fruit Cocktail', 'Del', 1, 115, '', 31),
(17, 'Lorado Pineapple Pieces', 'Lorado', 1, 99, '', 31),
(18, 'Heinz Tomato Ketchup', 'Heinz', 1, 119, '', 31),
(19, 'Del Monte Whole Kernel Corn', 'Del', 1, 115, '', 31),
(20, 'Mitchell’s Tomato Ketchup', 'Mitchell''s', 1, 135, '', 31),
(21, 'Pantenne Shampoo', 'Pantenne', 1, 445, '', 31),
(22, 'Coca Cola', 'Coca Cola', 12, 455, '', 31),
(23, 'Pepsi Cola', 'Pepsi', 6, 388, '', 31),
(24, 'Nestle Nesfruta', 'Nestle', 24, 315, '', 31),
(25, 'Nestle Pure Water', 'Nestle', 2, 219, '', 31),
(26, 'Jam-e-Shirin', 'Jam-e-Shirin', 1, 245, '', 31),
(27, 'Quice Syrup', 'Quice Syrup', 2, 125, '', 31),
(28, 'Fairy Lemon Dishwash Cleaner', 'Fairy Lemon Dishwash Cleaner', 1, 169, '', 31),
(29, 'OK Spiral', 'OK ', 3, 85, '', 31),
(30, 'Max Dishwash Bar', 'Max', 1, 38, '', 31),
(31, 'Surf Excel Detergent Powder', 'Surf Excel', 1, 935, '', 31),
(32, 'Comfort Fabric Softener', 'Comfort', 1, 89, '', 31),
(33, 'Bonus Tristar Detergent Powder', 'Bonus', 3, 125, '', 31),
(34, 'Sencor Element 7-V2', 'Sencor', 1, 7999, '', 31),
(35, 'Rockmars Car Audio & Video System', 'Rockmars Car Audio & Video System', 1, 13499, '', 31),
(36, 'Rockmars Car Audio & Video System', 'Rockmars Car Audio & Video System', 1, 21999, '', 31),
(37, 'Rockmars CD/USB-Receiver 640', 'Rockmars', 1, 4699, '', 31),
(38, 'Aurora Water Dispenser AWD-669BR', 'Aurora', 1, 13499, '', 31),
(39, 'Samsung 43” Plasma TV 43E400', 'Samsung', 1, 42999, '', 31),
(40, 'LG 42” LED TV 42LS3150', 'LG LED TV', 1, 60999, '', 31),
(41, 'Samsung 51” Plasma TV 51E470', 'Samsung', 1, 88999, '', 31),
(42, 'Sony 24” Slim LED TV 24EX430', 'Sony', 1, 28999, '', 31),
(43, 'Changhong 29” LED TV E29A6500', 'Changchong', 1, 2199, '', 31),
(44, 'Samsung Digital Camera ES95', 'Samsung', 1, 7399, '', 31),
(45, 'Nikon Digital Camera S-2700', 'Nikon', 1, 10999, '', 31),
(46, 'Fairline Stand Fan', 'Fairline', 1, 3499, '', 31),
(47, 'Aurora Rechargeable Fan 10” ARF-1010S', 'Aurora', 1, 3499, '', 31),
(48, 'Camelion Rechargeable Fan 12” ARF-624', 'Camelion', 1, 3499, '', 31),
(49, 'Camelion Rechargeable Fan 14” ARF-625', 'Camelion', 1, 3699, '', 31),
(50, 'Dawlance Inspire 30 1.5 Ton', 'Dawlance', 1, 35499, '', 31),
(51, '2By2 Trolley 4Pcs Set', '2By2 Trolley 4Pcs Set', 1, 2599, '', 31),
(52, '2By2 Trolley 4Pcs Set', '2By2 Trolley 4Pcs Set', 1, 3599, '', 31),
(53, 'Mitchells Vinegar', 'Mitchell''s', 1, 130, '', 31),
(54, 'Shangrila Imli Ginger Sauce', 'Shangrila', 1, 249, '', 31),
(55, 'Shangrila Tomato Ketchup', 'Shangrila', 1, 249, '', 31),
(56, 'Natioal Hot & Spicy Ketchup', 'National', 1, 139, '', 31),
(57, 'National Chilli Garlic Sauce', 'National', 1, 129, '', 31),
(58, ' National Hot and Spicy Ketchup 300grams', 'National', 1, 129, '', 31),
(59, 'White Chana', 'White Chana', 1, 180, '', 31),
(60, 'Black Chana', 'Black Chana', 1, 170, '', 31),
(61, 'Daal Sabit Masoor', 'Daal Sabit Masoor', 1, 189, '', 31),
(62, 'Daal Sabit Masoor', 'Daal Sabit Masoor', 1, 220, '', 31),
(63, 'Daal Chana', 'Daal Chana', 1, 225, '', 31),
(64, 'Mung Bean', 'Mung Bean', 1, 280, '', 31),
(65, 'Rice Pakki Basmati', 'Rice Pakki Basmati', 1, 320, '', 31),
(66, 'Rice Kachi Basmati', 'Rice Kachi Basmati', 1, 320, '', 31),
(67, 'Nurpur Butter 100 Grams', 'Nurpur', 1, 165, '', 31),
(68, 'Nestle Yogurt 250 Grams', 'Nestle', 1, 180, '', 31),
(69, 'Nestle Bhunna Jeera Raita 250 Grams', 'Nestle', 1, 100, '', 31),
(70, 'Puck Cream Cheese Spread 140 Grams', 'Puck', 1, 200, '', 31),
(71, ' Nestle Milk Pack 1 Litre', 'Nestle', 1, 150, '', 31),
(111, 'Surf Excel', 'Surf', 100, 120, '', 25),
(555, 'Candi Original', 'Continental Buscuits', 500, 15, NULL, 25),
(666, 'Qmobile E195', 'Qmobile', 100, 3000, './uploads/product/saads_96_96.png', 25);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `User_ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'User ID',
  `Email` varchar(500) NOT NULL COMMENT 'User Name / Email',
  `Password` varchar(500) NOT NULL COMMENT 'User Password',
  `User_Status` varchar(500) NOT NULL DEFAULT 'INACTIVE' COMMENT 'User Status',
  `Creation_Date` date NOT NULL COMMENT 'User tuple Creation date',
  `User_Type` int(11) NOT NULL DEFAULT '5' COMMENT 'User Role',
  PRIMARY KEY (`User_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='User Registration with Device Information' AUTO_INCREMENT=45 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_ID`, `Email`, `Password`, `User_Status`, `Creation_Date`, `User_Type`) VALUES
(25, 'shujaan3@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-05-03', 3),
(24, 'shujaan2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-05-03', 2),
(27, 'shujaan@hotmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-02', 1),
(28, 'shujaan2@hotmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-02', 2),
(29, 'kfc@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-02', 3),
(30, 'mcdonald@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-02', 3),
(31, 'shujaan4@hotmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-02', 4),
(32, 'cinema@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-02', 5),
(33, 'to.msaads@gmail.com', '44920363c0f788d01aa0d8dc1038e38c', 'ACTIVE', '2013-06-02', 3),
(35, 'gulahmed@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-05', 2),
(36, 'ebh@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-05', 2),
(37, 'levis@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-05', 2),
(38, 'samsung@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-05', 2),
(39, 'mother_care@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-05', 2),
(40, 'shujaan2@yahoo.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-05', 2),
(41, '14thstreetpizza@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-07', 3),
(42, 'kababji@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-07', 3),
(43, 'cafespasso@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-07', 3),
(44, 'optp@smartmall.com', 'e10adc3949ba59abbe56e057f20f883e', 'ACTIVE', '2013-06-07', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `Role_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Role_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`Role_ID`, `User_Name`) VALUES
(1, 'System Admin'),
(2, 'Clients - Shops'),
(3, 'Clients - Resturant'),
(4, 'Store Keeper'),
(5, 'Cinema'),
(6, 'Customer');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
